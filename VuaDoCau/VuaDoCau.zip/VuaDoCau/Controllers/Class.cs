﻿namespace VuaDoCau.Controllers
{
    public class Class
    {
    }
}
